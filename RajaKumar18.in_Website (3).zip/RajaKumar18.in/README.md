# RajaKumar18.in – Website Setup Guide

## 📁 Files in this Package

| File | Purpose |
|------|---------|
| `index.html` | Main Website (Full Homepage) |
| `firebase-messaging-sw.js` | Push Notification Service Worker |

---

## 🚀 Setup Instructions

### Step 1: Firebase Setup
1. `index.html` खोलें
2. `YOUR_API_KEY` की जगह अपनी **Firebase Console API Key** डालें
3. `firebase-messaging-sw.js` में भी `YOUR_API_KEY` replace करें
4. `YOUR_VAPID_KEY` की जगह **Web Push Certificate VAPID Key** डालें
   - Firebase Console → Project Settings → Cloud Messaging → Web Push Certificates

### Step 2: Google AdSense Setup
`index.html` में search करें `ca-pub-XXXXXXXXXXXXXXXX` और अपनी AdSense Publisher ID डालें।

Ad Slots available:
- **Header Ad** (728×90) – Line ~350
- **Middle Ad** (970×90) – Line ~430
- **Sidebar Ad** (300×600) – Daily Update section
- **Footer Ad** (728×90) – Bottom

### Step 3: Upload to Hosting
1. दोनों files को अपने hosting root में upload करें
2. **`firebase-messaging-sw.js`** को website ROOT में रखें (important!)
3. HTTPS ON होना जरूरी है

### Step 4: Add Your Links
`index.html` के नीचे JavaScript section में cards पर अपने links add करें:
```javascript
c.addEventListener('click', function(){
  window.open('https://your-link.com', '_blank');
});
```

---

## ✏️ Content Customize करना (Editable Sections)

### New Card Add करना (Tools/Courses/AI)
किसी भी grid section में यह HTML paste करें:
```html
<div class="card">
  <div class="card-icon ic-blue">🆕</div>
  <div class="card-title">New Tool Name</div>
  <div class="card-sub">Tool Description</div>
</div>
```

### New Trending Pill Add करना:
```html
<div class="trend-pill">
  <span class="t-num">9</span>
  <span>🆕 New Trend</span>
  <span class="fire-badge">🔥 Hot</span>
</div>
```

### New Download Item:
```html
<div class="dl-card">
  <div class="dl-icon">📦</div>
  <div class="dl-title">New Download</div>
  <div class="dl-btn">⬇️ Download</div>
</div>
```

---

## 🎨 Color Change करना

`index.html` के top में CSS Variables हैं:
```css
:root {
  --primary: #FF6B35;     ← Main Orange Color
  --secondary: #1A1A2E;   ← Dark Navy Color
  --accent: #FFD700;      ← Gold Accent
  --accent2: #00D4AA;     ← Teal Accent
}
```

---

## 📊 Analytics
Firebase Analytics पहले से configured है। बस `YOUR_API_KEY` fill करें।

---

## 📞 Contact
Email: rajahribabakumar@gmail.com  
Telegram: https://t.me/rajakumar18in  
Website: https://rajakumar18.in
