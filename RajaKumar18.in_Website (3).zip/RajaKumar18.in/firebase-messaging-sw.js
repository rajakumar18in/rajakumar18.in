// firebase-messaging-sw.js
// RajaKumar18.in – Firebase Push Notification Service Worker
// इस file को अपने website के ROOT folder में रखें (/)

importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyBU2nEW8g0OZjtLjevPdMRYhiJVJVSwA9o",
  authDomain: "rajakumar18in.firebaseapp.com",
  projectId: "rajakumar18in",
  storageBucket: "rajakumar18in.firebasestorage.app",
  messagingSenderId: "1091245207019",
  appId: "1:1091245207019:web:d3dead5b17ebef316f3dae"
});

const messaging = firebase.messaging();

// Background notification handler
messaging.onBackgroundMessage(function(payload) {
  console.log('[firebase-messaging-sw.js] Background Message:', payload);

  const notifTitle = payload.notification.title || 'RajaKumar18.in';
  const notifOptions = {
    body: payload.notification.body || 'New Update Available!',
    icon: '/icon.png',
    badge: '/badge.png',
    data: payload.data,
    actions: [
      { action: 'open', title: 'Open Website' },
      { action: 'close', title: 'Close' }
    ]
  };

  self.registration.showNotification(notifTitle, notifOptions);
});

// Notification click handler
self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  if (event.action === 'open' || !event.action) {
    event.waitUntil(
      clients.openWindow('https://rajakumar18.in')
    );
  }
});
